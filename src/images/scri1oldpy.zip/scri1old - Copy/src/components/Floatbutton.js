import React from 'react'
import {Link} from 'react-scroll'
function Floatbutton() {
  return (
    <div>
      <div className='btt2'>
        <Link to='#' className='cvbtn'>Login</Link>
        &nbsp;
        <Link to='#' className='cvbtn'>Contact Us</Link>
        </div>
    </div>
  )
}

export default Floatbutton
