import React from 'react'
import logo from '../images/nboy.png';
function Vision() {
  return (
    <div id='vision'>
      <div className='rgb-t1'>Vision.</div>
      <div className='pr3'>The Society for Collaborative Research and Innovation (SCRI) at IIT Mandi aims to foster a transformative research ecosystem to address local, national, and global challenges. Its vision includes:</div>
      <div className='nn'>
        <div className='np'><img src={logo} alt="logo" /></div>
        <div className='alldivs'>
      
        <div className='aimbox'>
            <h3>Promoting Interdisciplinary Research:</h3>
            <p className='para-align'>Uniting engineering, sciences, humanities, and management to tackle complex societal problems.</p>
        </div>
        <div className='aimbox'>
            <h3>Promoting Interdisciplinary Research:</h3>
            <p className='para-align'>Uniting engineering, sciences, humanities, and management to tackle complex societal problems.</p>
        </div>
        
        
        <div className='aimbox'>
            <h3>Promoting Interdisciplinary Research:</h3>
            <p className='para-align'>Uniting engineering, sciences, humanities, and management to tackle complex societal problems.</p>
        </div>
        <div className='aimbox'>
            <h3>Promoting Interdisciplinary Research:</h3>
            <p>Uniting engineering, sciences, humanities, and management to tackle complex societal problems.</p>
        </div>
        
     
        <div className='aimbox'>
            <h3>Promoting Interdisciplinary Research:</h3>
            <p className='para-align'>Uniting engineering, sciences, humanities, and management to tackle complex societal problems.</p>
       </div>
        <div className='aimbox'>
            <h3>Promoting Interdisciplinary Research:</h3>
            <p className='para-align'>Uniting engineering, sciences, humanities, and management to tackle complex societal problems.</p>
        </div>
        
        </div>
        </div>
        
    </div>
  )
}

export default Vision
