import React from 'react';
import './LetsConnect.css'; // Import the external CSS file

const LetsConnect = () => {
  return (
    <div className="lets-connect-container">
      <h1 className="lets-connect-heading">Let's Connect</h1>
      
      {/* Image Section */}
      <div className="images-section">
        <img src="IMAGE_URL_1" alt="Image 1" className="responsive-image" />
        <img src="IMAGE_URL_2" alt="Image 2" className="responsive-image" />
        <img src="IMAGE_URL_3" alt="Image 3" className="responsive-image" />
      </div>
      
      {/* Form Section */}
      <form className="connect-form">
        <input type="text" placeholder="Name" className="form-input" required />
        <input type="email" placeholder="Email" className="form-input" required />
        <input type="text" placeholder="Subject" className="form-input" required />
        <textarea placeholder="Message" className="form-textarea" rows="5" required></textarea>
        <button type="submit" className="connect-button">Connect Now</button>
      </form>
      
      {/* Footer Image */}
      <div className="footer-image-section">
        <img src="FOOTER_IMAGE_URL" alt="Footer Image" className="footer-image" />
      </div>
    </div>
  );
};

export default LetsConnect;
