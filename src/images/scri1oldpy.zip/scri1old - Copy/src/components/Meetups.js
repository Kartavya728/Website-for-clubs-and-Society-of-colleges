import React from 'react'
import  Events  from './Events'

function Meetups() {
  return (
    <div id='Meetups'>
      <div className='rgb-t1'>Meetups</div>
    </div>
  )
}

export default Meetups
