import React, { useState, useEffect } from 'react';
import logo from '../images/note.jpg';

function Email() {
  const [windowWidth, setWindowWidth] = useState(window.innerWidth);

  // Update window width on resize
  useEffect(() => {
    const handleResize = () => {
      setWindowWidth(window.innerWidth);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Define styles based on screen width
  const containerStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    backgroundColor: '#070B42FF',
    padding: windowWidth < 368 ? '10px' : '20px',
    borderRadius: '10px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    animation: windowWidth >= 368 ? 'faded-outer 7s 1 linear' : 'none', // Disable animation for width < 368px
    opacity: 1,
    zIndex: 100,
    justifyContent: 'space-around',
    position: 'relative', // Ensures the box remains fixed at its place
  };

  const anilrStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
  };

  const logoStyle = {
    height: windowWidth > 1024 ? '60px' : windowWidth > 768 ? '50px' : windowWidth > 368 ? '40px' : '30px',
    width: windowWidth > 1024 ? '60px' : windowWidth > 768 ? '50px' : windowWidth > 368 ? '40px' : '30px',
    marginBottom: '20px',
  };

  const headerStyle = {
    fontSize: windowWidth > 1024 ? '24px' : windowWidth > 768 ? '20px' : windowWidth > 368 ? '16px' : '14px',
    color: 'white',
    textAlign: 'center',
    marginBottom: '10px',
  };

  const paragraphStyle = {
    fontSize: windowWidth > 1024 ? '16px' : windowWidth > 768 ? '14px' : windowWidth > 368 ? '12px' : '10px',
    color: 'white',
    textAlign: 'center',
    marginBottom: '20px',
    padding: '0 10px', // Add padding for smaller screens to prevent text cutoff
  };

  const inputContainerStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    width: '100%',
  };

  const inputStyle = {
    width: '100%',
    maxWidth: windowWidth > 768 ? '400px' : windowWidth > 368 ? '300px' : '250px', // Adjust width for smaller screens
    padding: '10px',
    borderRadius: '5px',
    border: '1px solid #ccc',
    marginBottom: '20px',
    boxSizing: 'border-box',
    outline: 'none',
  };

  const buttonStyle = {
    padding: '10px 20px',
    backgroundColor: '#2eafe6',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    textDecoration: 'none',
    cursor: 'pointer',
    display: 'inline-block',
    fontSize: windowWidth < 368 ? '12px' : '14px', // Reduce button text size for smaller screens
    transition: 'background-color 0.3s',
  };

  return (
    <div style={containerStyle}>
      <div className="anilr" style={anilrStyle}>
        <img src={logo} alt="logo" style={logoStyle} />
        <h3 style={headerStyle}>Get Notified</h3>
        <p style={paragraphStyle}>
          Subscribe to our mailing list to know about upcoming events and publications.
        </p>
        <div style={inputContainerStyle}>
          <input
            type="email"
            placeholder="B24xxx@students.iitmandi.ac.in"
            style={inputStyle}
          />
          <a href="#" style={buttonStyle}>
            Subscribe
          </a>
        </div>
      </div>
    </div>
  );
}

export default Email;
