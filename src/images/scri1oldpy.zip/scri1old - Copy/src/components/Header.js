import React from 'react'
import NavBar from './NavBar'


function Header() {
  return (
    <div id='mai'>
    <NavBar/>
    </div>
  )
}

export default Header
