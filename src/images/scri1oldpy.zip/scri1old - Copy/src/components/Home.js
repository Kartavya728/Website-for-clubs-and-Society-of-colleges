import React from 'react'

function Home() {
  return (
    <div id='reanimate'>
      <div className='outtoin'>SCRI</div>
      <div className="just"><div className='ttanimate'>Society of Collabrative</div><div className='ttanimate'> Research and Innovation</div></div>
    </div>
  )
}

export default Home

