import React from 'react'

function Homies() {
  return (
    <div>
      <div id="main"></div>
    <div class="carousel">
      <div class="list">
          <div class="item">
              <img src="image/img8.jpg"/>
              <div class="content">
                  <div class="author">Research</div>
                  <div class="title">SCRI</div>
                  <div class="topic">IIT Mandi</div>
                  <div class="des">
                      Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ut sequi, rem magnam nesciunt minima placeat, itaque eum neque officiis unde, eaque optio ratione aliquid assumenda facere ab et quasi ducimus aut doloribus non numquam. Explicabo, laboriosam nisi reprehenderit tempora at laborum natus unde. Ut, exercitationem eum aperiam illo illum laudantium?
                  </div>
                  <div class="buttons">
                      <button>SEE MORE</button>
                      <button>Events</button>
                  </div>
              </div>
          </div>
          <div class="item">
              <img src="image/img7.jpg"/>
              <div class="content">
                  <div class="author">It's</div>
                  <div class="title">IIT Mandi</div>
                  <div class="topic">SCRI</div>
                  <div class="des">
                      Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ut sequi, rem magnam nesciunt minima placeat, itaque eum neque officiis unde, eaque optio ratione aliquid assumenda facere ab et quasi ducimus aut doloribus non numquam. Explicabo, laboriosam nisi reprehenderit tempora at laborum natus unde. Ut, exercitationem eum aperiam illo illum laudantium?
                  </div>
                  <div class="buttons">
                      <button>SEE MORE</button>
                      <button>Events</button>
                  </div>
              </div>
          </div>
          <div class="item">
              <img src="image/img6.jpg"/>
              <div class="content">
                  <div class="author">It's</div>
                  <div class="title">Research</div>
                  <div class="topic">Society</div>
                  <div class="des">
                      Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ut sequi, rem magnam nesciunt minima placeat, itaque eum neque officiis unde, eaque optio ratione aliquid assumenda facere ab et quasi ducimus aut doloribus non numquam. Explicabo, laboriosam nisi reprehenderit tempora at laborum natus unde. Ut, exercitationem eum aperiam illo illum laudantium?
                  </div>
                  <div class="buttons">
                      <button>SEE MORE</button>
                      <button>Events</button>
                  </div>
              </div>
          </div>
          <div class="item">
              <img src="image/img5.jpg"/>
              <div class="content">
                  <div class="author">It's</div>
                  <div class="title">SCRI</div>
                  <div class="topic">IIT</div>
                  <div class="des">
                      Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ut sequi, rem magnam nesciunt minima placeat, itaque eum neque officiis unde, eaque optio ratione aliquid assumenda facere ab et quasi ducimus aut doloribus non numquam. Explicabo, laboriosam nisi reprehenderit tempora at laborum natus unde. Ut, exercitationem eum aperiam illo illum laudantium?
                  </div>
                  <div class="buttons">
                      <button>SEE MORE</button>
                      <button>Events</button>
                  </div>
              </div>
          </div>
      </div>
      <div class="thumbnail">
          <div class="item">
              <img src="image/img8.jpg"/>
              <div class="content">
                  <div class="title">
                      Name Slider
                  </div>
                  <div class="description">
                      Description
                  </div>
              </div>
          </div>
          <div class="item">
              <img src="image/img7.jpg"/>
              <div class="content">
                  <div class="title">
                      Name Slider
                  </div>
                  <div class="description">
                      Description
                  </div>
              </div>
          </div>
          <div class="item">
              <img src="image/img6.jpg"/>
              <div class="content">
                  <div class="title">
                      Name Slider
                  </div>
                  <div class="description">
                      Description
                  </div>
              </div>
          </div>
          <div class="item">
              <img src="image/img5.jpg"/>
              <div class="content">
                  <div class="title">
                      Name Slider
                  </div>
                  <div class="description">
                      Description
                  </div>
              </div>
          </div>
      </div>

      <div class="arrows">
          <button id="prev">next</button>
          <button id="next">prev</button>
      </div>
      <div class="time"></div>
  </div>
</div>
  )
}

export default Homies
